---
name: huanaer-release
description: 花哪儿了（where-i-paid）的发版流水线。用于把改好的网页/官网发布到 Cloudflare Pages、把安卓安装包挂到官网下载、以及对线上做端到端验证。当需要发版、改完界面要上线、出 APK、或排查「本地改了但线上还是旧版」时使用。
agent_created: true
---

# 花哪儿了 · 发版流水线

一个 Cloudflare Pages 项目（`where-i-paid`）同时装三样东西，这也是最容易搞错的地方：

```
https://where-i-paid.pages.dev
├── /               官网（site/：首页、隐私、更新日志、download/）
├── /app/           应用（dist/ 整体拷进来，就是那个 PWA）
└── /api/couple/    情侣同步服务（functions/ + D1 jizhang-couple）
```

官网和 App 必须**同一个 origin**。分成两个域名就是两个 origin，用户装出来的是两份数据。

## 何时使用

- 改完 `assets/` 或 `site/`，要上线
- 要出安卓包装到官网
- 线上表现和本地不一致，怀疑没发上去 / 被缓存
- 要查「这个版本到底发了没有」

## 一条命令

```bash
node deploy.js                 # 构建 → 部署 → 验证（推荐）
node deploy.js --ver=1.19.0    # 先升版本再发
node deploy.js --dry           # 只构建，不部署
node deploy.js --no-verify     # 部署但不跑线上冒烟
```

`deploy.js` 在任何一步失败都会非零退出，不会出现「部署了其实是旧包」。**不要绕过它手工拼命令**，除非在排查它本身。

## 流水线各步归谁管

改代码前先知道哪一步负责什么，才不会改错地方：

| 步骤 | 脚本 | 产物 |
|---|---|---|
| 1. 收集要发布的文件 | `build-dist.js` | `dist/`（只含 FILES + `assets/`） |
| 2. 打进官网子目录 | `build-site.js` → `publishApp()` | `site/app/` + `site/_routes.json` |
| 3. 挂 APK（可选） | `build-site.js` → `shipApk()` | `site/download/whereipaid-vX.apk`，并写进 `site/app/version.json` |
| 4. 首页按钮改指向官网 | `build-site.js` → `relinkApk()` | 首页那个「下载 APK」不再指向 GitHub |
| 5. 打离线包 | `build-site.js` → `zipup()` | `site/download/huanaer-X.zip` |
| 6. 注入版本与体积 | `build-site.js` → `inject()` | 所有 `data-build="version\|size"` 处 |
| 7. 自检 | `build-site.js` → `check()` | 不通过就非零退出，不部署 |

顺序不能反：体积是产物的属性，先写死再打包，页面标的数字和用户下到的东西永远是两回事。

## 要发 APK 时

APK 不是 `build-site.js` 打的，它只负责「找到就挂上去」：

```bash
node android/make-apk.js      # 需要 JAVA_HOME=JDK17、ANDROID_HOME
node deploy.js
```

**先打 APK 再 deploy。** 顺序反了 `shipApk()` 会打印「APK 未找到」然后跳过——不报错，很容易误以为发了，实际官网还指着 GitHub。

## 验证判据

`deploy.js` 部署后自动跑这几项，全过才算发完：

| 检查 | 通过条件 |
|---|---|
| `/api/couple/health` | 200 且 `{"ok":true,"v":2}` |
| `/` | 200，含「花哪儿了」 |
| `/app/` | 200，含 `assets/js/app.js` |
| `/app/sw.js` | 200，且里面的 `CACHE` 等于本次版本 |
| 线上冒烟 | `verify-sync-live.js` 15/15（会建临时房间，跑完自删） |

第 4 项是判断「部署到底生效没有」的关键——它读的是线上文件，不是本地。

## 版本纪律

- **唯一来源是 `sw.js` 的 `CACHE`**（`jizhang-vX.Y.Z`）
- `index.html` 里 23 处 `?v=` 由 `_test/bump.js` 统一改，**不要手改**
- `site/*.html` 的版本与体积由 `inject()` 写，**不要手改**
- 发版后跑一次 `node _test/bump.js --check`，它会校验 `?v=` 与 `CACHE` 全等

## 五个坑（都真踩过）

1. **代理会让 `pages.dev` 返回 522。** 本机 `http_proxy` 开着时访问线上地址会 522，绕过代理直连 0.3s 就通。`wrangler` 的部署请求走代理没问题，但**验证必须绕代理**（`curl --noproxy '*'`；`deploy.js` 里的 fetch 不读代理环境变量，天然绕开）。
2. **Pages 默认 pretty URL。** `/privacy.html` 会 308 到 `/privacy`。用 curl 验证要带 `-L`，否则拿到 0 字节空文件，会误判「线上没更新」。
3. **`site/app/` 是构建产物，不要手改、不要提交**（已在 `.gitignore`）。改 App 就改 `assets/`，然后重新构建。
4. **`site/_routes.json` 只 include `/api/*`。** 少了它所有静态请求都会过一遍 Functions，慢且浪费额度；写成 include `/*` 更糟，官网会被 Functions 接管。
5. **微信 UA 会把安装按钮变灰**（`.is-wechat .pcard .btn{pointer-events:none}`）。这是故意的——微信里不能添加到主屏幕。测微信内表现要覆盖 UA，别以为按钮坏了。

## 不要做的事

- 不要手改 `index.html` 的 `?v=` 或 `site/` 里的版本号
- 不要手改 `site/app/`（重新构建）
- 不要在 `deploy.js` 里塞全量回归（9 分钟）；发版前单独跑 `node _test/run-all.js`
- 不要跳过验证就说「已上线」——`--no-verify` 只用于明确知道风险时
- 不要把 App 和官网分到两个 Pages 项目

## 失败排查

| 现象 | 先查 |
|---|---|
| 522 / TLS 握手失败 | 是不是走了代理；`curl --noproxy '*'` 再试 |
| 部署成功但页面没变 | 线上 `sw.js` 里的版本号对不对；浏览器 SW 缓存（关掉再开 / 硬刷新） |
| 官网正常、`/app/` 白屏 | `site/app/index.html` 存在吗；`_routes.json` 是不是把静态也拦了 |
| `/app/` 能开但装不上 | `manifest` 与 `sw.js` 都在 `/app/` 下吗；SW scope 应为 `/app/` |
| APK 链接还在 GitHub | `dist-apk/whereipaid-v<ver>.apk` 不存在，先跑 `android/make-apk.js` |
| 自检报「体积文案与实物差超过 10%」 | zip 里有不该发的东西（比如 `_test/`），检查 `build-dist.js` 的 FILES |

## 相关文件

```
deploy.js                    一条命令（本 skill 的执行入口）
build-site.js                官网构建：app/ + apk + zip + 注入 + 自检
build-dist.js                挑文件进 dist/
android/make-apk.js          出 APK（需要 JDK17 + Android SDK）
_test/bump.js                版本号唯一入口（--check 只校验）
_test/verify-sync-live.js    线上端到端冒烟（SYNC_BASE 指哪打哪）
_test/run-all.js             全量回归（27 套件 / 1058 断言）
wrangler.toml                Pages 项目 + D1 绑定
schema.sql                   D1 建表
```
